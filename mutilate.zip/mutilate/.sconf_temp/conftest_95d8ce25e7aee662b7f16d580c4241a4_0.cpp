


#ifdef __cplusplus
extern "C"
#endif
char clock_gettime();

int
main() {
  clock_gettime();
return 0;
}
